#this is just an example using rsi 1h
#buying whenever it drops below 15

#this "environment" have access to about anything
#the "data" object have all whats needed for strategy development such 
#as open orders, historic orders (submitted from here or else) or
#live price data, orderbook, candles, indicators or whatever other
#used plugins.. as well as unrestricted python
#access to libs,disk,network or any other source

# data.print("1h RSI %s" % data.ind.rsi.last)
# data.print("1h ADXR %s" % data.ind.adxr.last)
# data.print("1h ADX (normal) %s" % data.ind.dmi.adx[0]) #alsohave (plusdi,minusdi,plusdm,minusdm)
# data.print("1h MACD: macd %s histogram %s signal %s" % (data.ind.macd.index[0], data.ind.macd.histogram[0], data.ind.macd.signal[0]))
# data.print("1h SAR value: current(%s) previous(%s)" % (data.ind.sar.index[0], data.ind.sar.index[1]))
# data.print("1h HullMA %s" % data.ind.hullma.last)
# return

# ff = _rsi(data.ind.macd.signal, 14)
# print(ff[0])
# data.print("RT %s" % (lastprice()))
data.print("RSI %s" % data.ind.rsi.last)
# # print(lastprice())
# return

if data.ind.rsi.last < 50:
	if executedqty("buy") == 1 or activeqty("buy") > 0: return
	neworder("buy", lastprice(), 1)
	return
if data.ind.rsi.last >= 65:
	if executedqty("sell") == 1 or activeqty("sell") > 0: return
	neworder("sell", lastprice(), 1)
	return
# if data.ind.macd.signal[0] > data.ind.macd.index[0]:
# 	print(“Do Sell”)
# if (data.ind.macd.signal[0]) < (data.ind.macd.index[0]):
#   print(“Do Buy”)
# if data.ind.macd.signal[0] > data.ind.macd.index[0]:
#   neworder("sell", lastprice(), 1)
# elif data.ind.macd.signal[0] < data.ind.macd.index[0]:
#   neworder("buy", lastprice(), 1)

# position = executedqty("sell", data.orders)
# txt = "The position holds {} contracts"
# print(txt.format(position))