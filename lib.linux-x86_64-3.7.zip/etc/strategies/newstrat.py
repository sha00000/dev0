if data.ind.rsi1h.last < 15:
	neworder("buy", lastprice(), 1)
	return
 