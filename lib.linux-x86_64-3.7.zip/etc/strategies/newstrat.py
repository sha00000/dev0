#built-in functions
#executedqty: returns the last continuous buy/sell executed quantities
#activeqty:   returns the last continuous buy/sell active quantities

#built-in variables
#data:
	#data.price: the last price of this symbol
	#data.orders: sorted list of all orders
	#data.ind: indicators results eg: data.ind.rsi.last
	#data.symbol: this symbol
	#data.sts: strategy start timestamp
	#data.print(function): framework print function


data.print("P %s RSI %s" % (data.ind.candles[-1], data.ind.rsi.last))

# data.print("RSI %s" % )

# if data.ind.rsi.last < 20:
# 	if executedqty("buy") == 1 or activeqty("buy") > 0 or activeqty("sell") > 0: return
# 	neworder("buy", data.price-10, 1)
# 	return
# if data.ind.rsi.last >= 65:
# 	if executedqty("sell") == 1 or activeqty("sell") > 0 or activeqty("buy") > 0: return
# 	if executedqty("buy") > 0: neworder("sell", data.price, 1)
# 	return