# data.print("1h %s" % data.ind.rsi1h.last)
# return
if data.ind.rsi1h.last < 15:
	lastp = lastprice()
	data.neworder("buy", lastp, 1)
	return