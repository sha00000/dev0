from time import time,sleep
from etc  import strategyfuncs
class StrategyCodeTemplate(object):
	__slots__ = ()
	def __init__(self): pass

	def runcode(self, data):
		def __lp__(): return strategyfuncs.lastprice(data)
		lastprice   = __lp__
		executedqty = strategyfuncs.executedqty
		activeqty   = strategyfuncs.activeqty
		neworder    = data.neworder
		###PLACEHOLDER###