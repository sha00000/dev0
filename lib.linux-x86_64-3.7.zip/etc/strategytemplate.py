from time import time,sleep
from etc  import strategyfuncs
class StrategyCodeTemplate(object):
	__slots__ = ()
	def __init__(self): pass

	def runcode(self, data):
		def __lp__(): return strategyfuncs.lastprice(data)
		def __aqty__(side): return strategyfuncs.activeqty(side, data.orders)
		def __eqty__(side): return strategyfuncs.executedqty(side, data.orders)
		lastprice   = __lp__
		activeqty   = __aqty__
		executedqty = __eqty__
		# executedqty = strategyfuncs.executedqty
		# activeqty   = strategyfuncs.activeqty
		neworder    = data.neworder
		###PLACEHOLDER###