from time import time,sleep
class StrategyCodeTemplate(object):

	__slots__ = ()

	def __init__(self):
		pass

	def runcode(self, data):
		###PLACEHOLDER###
