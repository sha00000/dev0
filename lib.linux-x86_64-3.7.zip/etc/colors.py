
class Colors(object):

	__slots__ = [
		"HEADER",
		"OKBLUE",
		"OKGREEN",
		"WARNING",
		"FAIL",
		"ENDC",
		"BOLD",
		"UNDERLINE",
		"esc",
		"blackf",
		"redf",
		"greenf",
		"yf",
		"bluef",
		"purplef",
		"cyanf",
		"whitef",
		"blackb",
		"redb",
		"greenb",
		"yellowb",
		"blueb",
		"purpleb",
		"cyanb",
		"whiteb",
		"boldon",
		"boldoff",
		"italicson",
		"italicsoff",
		"ulon",
		"uloff",
		"invon",
		"invoff",
		"reset",
		
		"resetall",
		"bold",
		"dim",
		"underlined",
		"blink",
		"reverse",
		"hidden",
		"resetbold",
		"resetdim",
		"resetunderlined",
		"resetblink",
		"resetreverse",
		"resethidden",
		"default",
		"black",
		"red",
		"green",
		"yellow",
		"blue",
		"magenta",
		"cyan",
		"lightgray",
		"darkgray",
		"lightred",
		"lightgreen",
		"lightyellow",
		"lightblue",
		"lightmagenta",
		"lightcyan",
		"white",
		"backgrounddefault",
		"backgroundblack",
		"backgroundred",
		"backgroundgreen",
		"backgroundyellow",
		"backgroundblue",
		"backgroundmagenta",
		"backgroundcyan",
		"backgroundlightgray",
		"backgrounddarkgray",
		"backgroundlightred",
		"backgroundlightgreen",
		"backgroundlightyellow",
		"backgroundlightblue",
		"backgroundlightmagenta",
		"backgroundlightcyan",
		"backgroundwhite"
		]
	
	def __init__(self):
		self.resetall   = "\033[0m"
		self.bold       = "\033[1m"
		self.dim        = "\033[2m"
		self.underlined = "\033[4m"
		self.blink      = "\033[5m"
		self.reverse    = "\033[7m"
		self.hidden     = "\033[8m"
		self.resetbold       = "\033[21m"
		self.resetdim        = "\033[22m"
		self.resetunderlined = "\033[24m"
		self.resetblink      = "\033[25m"
		self.resetreverse    = "\033[27m"
		self.resethidden     = "\033[28m"
		self.default      = "\033[39m"
		self.black        = "\033[30m"
		self.red          = "\033[31m"
		self.green        = "\033[32m"
		self.yellow       = "\033[33m"
		self.blue         = "\033[34m"
		self.magenta      = "\033[35m"
		self.cyan         = "\033[36m"
		self.lightgray    = "\033[37m"
		self.darkgray     = "\033[90m"
		self.lightred     = "\033[91m"
		self.lightgreen   = "\033[92m"
		self.lightyellow  = "\033[93m"
		self.lightblue    = "\033[94m"
		self.lightmagenta = "\033[95m"
		self.lightcyan    = "\033[96m"
		self.white        = "\033[97m"
		self.backgrounddefault      = "\033[49m"
		self.backgroundblack        = "\033[40m"
		self.backgroundred          = "\033[41m"
		self.backgroundgreen        = "\033[42m"
		self.backgroundyellow       = "\033[43m"
		self.backgroundblue         = "\033[44m"
		self.backgroundmagenta      = "\033[45m"
		self.backgroundcyan         = "\033[46m"
		self.backgroundlightgray    = "\033[47m"
		self.backgrounddarkgray     = "\033[100m"
		self.backgroundlightred     = "\033[101m"
		self.backgroundlightgreen   = "\033[102m"
		self.backgroundlightyellow  = "\033[103m"
		self.backgroundlightblue    = "\033[104m"
		self.backgroundlightmagenta = "\033[105m"
		self.backgroundlightcyan    = "\033[106m"
		self.backgroundwhite        = "\033[107m"

		self.HEADER = '\033[95m'
		self.OKBLUE = '\033[94m'
		self.OKGREEN = '\033[92m'
		self.WARNING = '\033[93m'
		self.FAIL = '\033[91m'
		self.ENDC = '\033[0m'
		self.BOLD = '\033[1m'
		self.UNDERLINE = '\033[4m'
		self.esc = "\x1b"
		self.blackf = self.esc + "[30m"
		self.redf = self.esc + "[31m"
		self.greenf = self.esc + "[32m"
		self.yf = self.esc + "[33m"
		self.bluef = self.esc + "[34m"
		self.purplef = self.esc + "[35m"
		self.cyanf = self.esc + "[36m"
		self.whitef = self.esc + "[37m"
		self.boldon = self.esc + "[1m"
		self.boldoff = self.esc + "[22m"
		self.italicson = self.esc + "[3m"
		self.italicsoff = self.esc + "[23m"
		self.ulon = self.esc + "[4m"
		self.uloff = self.esc + "[24m"
		self.invon = self.esc + "[7m"
		self.invoff = self.esc + "[27m"
		self.reset = self.esc + "[0m"
